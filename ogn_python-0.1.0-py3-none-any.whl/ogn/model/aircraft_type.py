class AircraftType:
    unknown = 0
    glider_or_motor_glider = 1
    tow_tug_plane = 2
    helicopter_rotorcraft = 3
    parachute = 4
    drop_plane = 5
    hang_glider = 6
    para_glider = 7
    powered_aircraft = 8
    jet_aircraft = 9
    flying_saucer = 10
    balloon = 11
    airship = 12
    unmanned_aerial_vehicle = 13
    static_object = 15
